/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package micevisualization;

/**
 *
 * @author parker
 */
public class Dimensions {
    double w;
    double h;
    
    Dimensions(double w_p, double h_p) {
        this.w = w_p;
        this.h = h_p;
    }
}
